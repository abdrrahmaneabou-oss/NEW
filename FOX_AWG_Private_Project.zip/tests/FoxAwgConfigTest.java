package com.ponie.dayov12;

import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermissions;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.*;

public final class FoxAwgConfigTest {
    private static void check(boolean b) { if(!b) throw new AssertionError("Validation assertion failed"); }
    public static void main(String[] args) throws Exception {
        String key=Base64.getEncoder().encodeToString(new byte[32]);
        String text="[Interface]\nAddress = 100.64.0.2/32\nPrivateKey = "+key+"\nHeaderProtectionKey = "+key
            +"\nRekeyAfterTime = 100-120\nI1 = <b 0x0019><r 12>\nDNS = 100.64.0.1, 8.8.4.4\n"
            +"[Peer]\nPublicKey = "+key+"\nEndpoint = 127.0.0.1:12345\nAllowedIPs = 0.0.0.0/0, ::/0\nPersistentKeepalive = 25-35\n";
        FoxAwgConfig c=FoxAwgConfig.parse(text.getBytes(StandardCharsets.UTF_8));
        String u=c.uapi();
        check(u.contains("rekey_after_time=100-120\n"));
        check(u.contains("persistent_keepalive_interval=25-35\n"));
        check(u.contains("i1=<b 0x0019><r 12>\n"));
        check(u.contains("header_protection_key="+String.join("",Collections.nCopies(64,"0"))+"\n"));
        check(u.indexOf("public_key=") < u.indexOf("allowed_ip="));
        for(String invalid:new String[]{text.replace("DNS =", "Unrecognized ="),text+"[Peer]\n",text.replace("25-35",""),text.replace("[Interface]", "[Unknown]")}) {
            boolean rejected=false;
            try { FoxAwgConfig.parse(invalid.getBytes(StandardCharsets.UTF_8)); } catch(IOException e) { rejected=true; check(!e.getMessage().contains(key)); }
            check(rejected);
        }
        if(args.length>0) {
            byte[] original=Files.readAllBytes(Paths.get(args[0]));
            c=FoxAwgConfig.parse(original); u=c.uapi(); Arrays.fill(original,(byte)0);
            check(c.iface.containsKey("HeaderProtectionKey"));
            check(u.contains("rekey_after_time="+c.iface.get("RekeyAfterTime")+"\n"));
            if(args.length>1) {
                Path out=Paths.get(args[1]);
                Files.createFile(out,PosixFilePermissions.asFileAttribute(PosixFilePermissions.fromString("rw-------")));
                Files.write(out,u.getBytes(StandardCharsets.UTF_8));
            }
            System.out.println("Actual configuration: all "+(c.iface.size()+c.peer.size())+" fields recognized; keys and values omitted.");
        }
        System.out.println("PASS: strict parsing, key conversion, parameter preservation, invalid-input rejection.");
    }
}
