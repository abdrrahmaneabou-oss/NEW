package com.ponie.dayov12;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.Arrays;

public final class FoxAwgUi {
    private static final int IMPORT=17439;
    public static void attach(Activity activity) {
        Button button=new Button(activity); button.setText("AWG ⚙");
        FrameLayout.LayoutParams layout=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.END);
        int d=(int)(activity.getResources().getDisplayMetrics().density*12);
        layout.setMargins(d,d,d,d);
        activity.addContentView(button,layout);
        button.setOnClickListener(v -> new AlertDialog.Builder(activity)
            .setTitle("FOX + AmneziaWG 3.1 (experimental)")
            .setMessage((FoxConfigStore.exists(activity)?"Configuration imported":"Import ro.conf before connecting")
                +"\n\n"+FoxTransport.status()+"\n\nAll phone apps use AWG. Original FOX processing is limited to the original game packages.\nFor protection after a crash or manual disconnect, enable Android's Block connections without VPN.")
            .setPositiveButton("Import .conf",(dialog,which) -> {
                if(MyVpnService.isVpnRunning) { toast(activity,"Stop FOX VPN before replacing configuration"); return; }
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
                activity.startActivityForResult(intent,IMPORT);
            })
            .setNeutralButton("Android VPN settings",(dialog,which) -> activity.startActivity(new Intent(Settings.ACTION_VPN_SETTINGS)))
            .setNegativeButton("Close",null).show());
    }
    public static boolean result(Activity activity,int request,int result,Intent data) {
        if(request!=IMPORT) return false;
        if(result!=Activity.RESULT_OK||data==null||data.getData()==null) return true;
        if(MyVpnService.isVpnRunning) { toast(activity,"Stop VPN before importing"); return true; }
        new Thread(() -> {
            byte[] plaintext=null;
            try(InputStream in=activity.getContentResolver().openInputStream(data.getData())) {
                if(in==null) throw new IOException("FILE_NOT_OPENED");
                plaintext=FoxAwgConfig.readLimited(in);
                FoxConfigStore.save(activity,plaintext);
                new Handler(Looper.getMainLooper()).post(() -> toast(activity,"AmneziaWG configuration imported securely"));
            } catch(Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> toast(activity,"Import failed: unsupported or invalid configuration"));
            } finally { if(plaintext!=null) Arrays.fill(plaintext,(byte)0); }
        },"AWG-Import").start();
        return true;
    }
    private static void toast(Activity a,String text) { Toast.makeText(a,text,Toast.LENGTH_LONG).show(); }
}
