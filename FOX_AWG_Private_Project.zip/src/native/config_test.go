package main

import (
    "os"
    "testing"
    "strings"
    "github.com/amnezia-vpn/amneziawg-go/v3/conn"
    "github.com/amnezia-vpn/amneziawg-go/v3/device"
    "golang.org/x/sys/unix"
)

func TestActualConfigAgainstOfficialCore(t *testing.T) {
    path:=os.Getenv("FOX_AWG_UAPI_FILE")
    if path=="" { t.Skip("no private fixture configured") }
    settings,err:=os.ReadFile(path)
    if err!=nil { t.Fatal("fixture unavailable") }
    fds,err:=unix.Socketpair(unix.AF_UNIX,unix.SOCK_DGRAM,0)
    if err!=nil { t.Fatal(err) }
    defer unix.Close(fds[1])
    bridge,err:=newPacketTun(fds[0],1280)
    if err!=nil { t.Fatal(err) }
    d:=device.NewDevice(bridge,conn.NewStdNetBind(),device.NewLogger(device.LogLevelSilent,""))
    defer d.Close()
    // No Up(): do not connect to or authenticate with the real user server.
    if err:=d.IpcSet(string(settings)); err!=nil { t.Fatal("official AWG core rejected configuration") }
    serialized,err:=d.IpcGet()
    if err!=nil { t.Fatal("configuration roundtrip failed") }
    actual:=make(map[string]string)
    for _,line:=range strings.Split(serialized,"\n") {
        parts:=strings.SplitN(line,"=",2)
        if len(parts)==2 { actual[parts[0]]=parts[1] }
    }
    for _,line:=range strings.Split(string(settings),"\n") {
        parts:=strings.SplitN(line,"=",2)
        if len(parts)!=2 {continue}
        key:=parts[0]
        // X25519 private scalars are intentionally clamped by the official core.
        if key=="private_key"||key=="replace_peers"||key=="replace_allowed_ips"||key=="allowed_ip"||key=="endpoint" {continue}
        if actual[key]!=parts[1] {t.Fatal("roundtrip mismatch in field:",key)}
    }
    for i:=range settings { settings[i]=0 }
}
