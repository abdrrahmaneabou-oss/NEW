package main

import (
    "strconv"
    "strings"
)

func handshakeSeconds(settings string) int64 {
    var latest int64
    for _, line := range strings.Split(settings, "\n") {
        if strings.HasPrefix(line, "last_handshake_time_sec=") {
            v, err := strconv.ParseInt(strings.TrimPrefix(line, "last_handshake_time_sec="), 10, 64)
            if err == nil && v > latest { latest = v }
        }
    }
    return latest
}
