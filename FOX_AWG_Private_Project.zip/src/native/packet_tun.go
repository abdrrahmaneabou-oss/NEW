package main

import (
    "io"
    "os"
    "sync"

    "github.com/amnezia-vpn/amneziawg-go/v3/tun"
    "golang.org/x/sys/unix"
)

// packetTun is an internal datagram socket, NOT a second Android VPN/TUN.
// One datagram is exactly one complete IP packet, in both directions.
type packetTun struct {
    file *os.File
    fd int
    mtu int
    events chan tun.Event
    once sync.Once
}

func newPacketTun(fd int, mtu int) (*packetTun, error) {
    if err := unix.SetNonblock(fd, true); err != nil { return nil, err }
    t := &packetTun{file: os.NewFile(uintptr(fd), "fox-packet-bridge"), fd: fd, mtu: mtu, events: make(chan tun.Event, 1)}
    return t, nil
}
func (t *packetTun) File() *os.File { return t.file }
func (t *packetTun) Name() (string, error) { return "foxawg", nil }
func (t *packetTun) MTU() (int, error) { return t.mtu, nil }
func (t *packetTun) BatchSize() int { return 1 }
func (t *packetTun) Events() <-chan tun.Event { return t.events }
func (t *packetTun) Read(bufs [][]byte, sizes []int, offset int) (int, error) {
    n, err := t.file.Read(bufs[0][offset:])
    if err != nil { return 0, err }
    if n == 0 { return 0, io.EOF }
    sizes[0] = n
    return 1, nil
}
func (t *packetTun) Write(bufs [][]byte, offset int) (int, error) {
    for i, b := range bufs {
        if _, err := t.file.Write(b[offset:]); err != nil { return i, err }
    }
    return len(bufs), nil
}
func (t *packetTun) Close() error {
    var err error
    t.once.Do(func() { unix.Shutdown(t.fd, unix.SHUT_RDWR); err = t.file.Close(); close(t.events) })
    return err
}
