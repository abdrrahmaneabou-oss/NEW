//go:build android

// JNI bridge only. Cryptography and protocol are the pinned official AWG core.
#include <jni.h>
#include <stdlib.h>

extern int foxTurnOn(int fd, int mtu, const char *settings);
extern void foxTurnOff(void);
extern int foxSocket(int family);
extern long long foxHandshake(void);

JNIEXPORT jint JNICALL Java_com_ponie_dayov12_FoxNative_turnOn(JNIEnv *env, jclass clazz, jint fd, jint mtu, jstring settings) {
    const char *text = (*env)->GetStringUTFChars(env, settings, NULL);
    if (!text) return -5;
    int result = foxTurnOn(fd, mtu, text);
    (*env)->ReleaseStringUTFChars(env, settings, text);
    return result;
}
JNIEXPORT void JNICALL Java_com_ponie_dayov12_FoxNative_turnOff(JNIEnv *env, jclass clazz) { foxTurnOff(); }
JNIEXPORT jint JNICALL Java_com_ponie_dayov12_FoxNative_socket(JNIEnv *env, jclass clazz, jint family) { return foxSocket(family); }
JNIEXPORT jlong JNICALL Java_com_ponie_dayov12_FoxNative_handshake(JNIEnv *env, jclass clazz) { return foxHandshake(); }
