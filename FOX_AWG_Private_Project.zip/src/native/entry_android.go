//go:build android

package main

/*
#include <stdlib.h>
*/
import "C"

import (
    "sync"
    "github.com/amnezia-vpn/amneziawg-go/v3/conn"
    "github.com/amnezia-vpn/amneziawg-go/v3/device"
    "golang.org/x/sys/unix"
)

var nativeMu sync.Mutex
var activeDevice *device.Device

//export foxTurnOn
func foxTurnOn(fd C.int, mtu C.int, settings *C.char) C.int {
    nativeMu.Lock()
    defer nativeMu.Unlock()
    if activeDevice != nil { unix.Close(int(fd)); return -2 }
    // Never log configuration, keys, or server settings.
    logger := &device.Logger{Verbosef: device.DiscardLogf, Errorf: device.DiscardLogf}
    t, err := newPacketTun(int(fd), int(mtu))
    if err != nil { unix.Close(int(fd)); return -6 }
    d := device.NewDevice(t, conn.NewStdNetBind(), logger)
    if err := d.IpcSet(C.GoString(settings)); err != nil { d.Close(); return -3 }
    d.DisableSomeRoamingForBrokenMobileSemantics()
    if err := d.Up(); err != nil { d.Close(); return -4 }
    activeDevice = d
    return 1
}

//export foxTurnOff
func foxTurnOff() {
    nativeMu.Lock()
    d := activeDevice
    activeDevice = nil
    nativeMu.Unlock()
    if d != nil { d.Close() }
}

//export foxSocket
func foxSocket(family C.int) C.int {
    nativeMu.Lock()
    defer nativeMu.Unlock()
    if activeDevice == nil { return -1 }
    b, ok := activeDevice.Bind().(conn.PeekLookAtSocketFd)
    if !ok { return -1 }
    var fd int
    var err error
    if int(family) == 4 { fd, err = b.PeekLookAtSocketFd4() } else { fd, err = b.PeekLookAtSocketFd6() }
    if err != nil { return -1 }
    return C.int(fd)
}

//export foxHandshake
func foxHandshake() C.longlong {
    nativeMu.Lock()
    defer nativeMu.Unlock()
    if activeDevice == nil { return -1 }
    // Parse only the handshake field; UAPI also contains private keys.
    s, err := activeDevice.IpcGet()
    if err != nil { return -1 }
    return C.longlong(handshakeSeconds(s))
}

func main() {}
