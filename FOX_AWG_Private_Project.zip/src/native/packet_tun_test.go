package main

import (
    "bytes"
    "os"
    "testing"
    "time"
    "golang.org/x/sys/unix"
)

func TestPacketBoundaries(t *testing.T) {
    fds, err := unix.Socketpair(unix.AF_UNIX, unix.SOCK_DGRAM, 0)
    if err != nil { t.Fatal(err) }
    tunnel, err := newPacketTun(fds[0], 1280)
    if err != nil { t.Fatal(err) }
    defer tunnel.Close()
    peer := os.NewFile(uintptr(fds[1]), "test-peer")
    defer peer.Close()
    packets := [][]byte{{0x45, 1, 2}, {0x60, 3, 4, 5, 6}}
    for _, p := range packets { if _, err := peer.Write(p); err != nil { t.Fatal(err) } }
    for _, want := range packets {
        b := make([]byte, 65536)
        sizes := []int{0}
        if n, err := tunnel.Read([][]byte{b}, sizes, 32); err != nil || n != 1 { t.Fatalf("read: %d %v", n, err) }
        if !bytes.Equal(b[32:32+sizes[0]], want) { t.Fatal("datagram boundary changed") }
    }
    for _, p := range packets {
        withOffset := append(make([]byte, 32), p...)
        if _, err := tunnel.Write([][]byte{withOffset}, 32); err != nil { t.Fatal(err) }
        b := make([]byte, 65536)
        n, err := peer.Read(b)
        if err != nil || !bytes.Equal(b[:n], p) { t.Fatal("inbound boundary changed", err) }
    }
}
func TestHandshakeOnly(t *testing.T) {
    if got := handshakeSeconds("private_key=not-for-output\nlast_handshake_time_sec=5\nlast_handshake_time_sec=12\n"); got != 12 { t.Fatal(got) }
}
func TestCloseUnblocksReader(t *testing.T) {
    fds, err := unix.Socketpair(unix.AF_UNIX, unix.SOCK_DGRAM, 0)
    if err != nil { t.Fatal(err) }
    defer unix.Close(fds[1])
    tunnel, err := newPacketTun(fds[0],1280)
    if err != nil { t.Fatal(err) }
    done:=make(chan struct{})
    go func() { tunnel.Read([][]byte{make([]byte,1280)},[]int{0},0); close(done) }()
    tunnel.Close()
    select { case <-done: case <-time.After(time.Second): t.Fatal("blocked reader survived close") }
}
