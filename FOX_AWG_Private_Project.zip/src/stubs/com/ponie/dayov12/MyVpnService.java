package com.ponie.dayov12;

// Compile-time declaration ONLY. Never added to APK; original Smali is kept.
public class MyVpnService extends android.net.VpnService implements Runnable {
    volatile boolean run, active;
    public static boolean isVpnRunning;
    int tip;
    android.os.ParcelFileDescriptor tun;
    java.nio.channels.FileChannel tunOutChannel;
    void handleIPv4Packet(byte[] data,int len,java.nio.channels.FileChannel out) {}
    void m_bcs() {}
    void doStop() {}
    void writeTunSafe(java.nio.channels.FileChannel out,byte[] packet) {}
    public void run() {}
}
