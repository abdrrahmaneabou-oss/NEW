#!/usr/bin/env python3
"""Private reproducible project archive; deliberately excludes VPN fixtures."""
import argparse
import hashlib
import zipfile
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument("root",type=Path);p.add_argument("original",type=Path);p.add_argument("output",type=Path)
a=p.parse_args();entries=[]
for folder in ("src","scripts","tests","licenses"):
    entries.extend((path,path.relative_to(a.root).as_posix()) for path in sorted((a.root/folder).rglob("*"))
                   if path.is_file() and "__pycache__" not in path.parts)
for filename in ("README_AR.md",".gitignore"):
    entries.append((a.root/filename,filename))
for filename in ("patch-audit.json","repack-audit.json","final-audit.json","test-results.txt","dependency-sha256.txt"):
    entries.append((a.root/filename,"audit/"+filename))
entries.extend(((a.original,"input/FOX_ORIGINAL.apk"),
                (a.root/"private-build-signing.p12","signing/private-build-signing.p12"),
                (a.root/"native-arm64/libfox-awg.so","prebuilt/arm64-v8a/libfox-awg.so")))
with zipfile.ZipFile(a.output,"w",zipfile.ZIP_DEFLATED) as z:
    hashes=[]
    for path,name in entries:
        assert not name.endswith((".conf",".secret"))
        z.write(path,name);hashes.append(hashlib.sha256(path.read_bytes()).hexdigest()+"  "+name)
    z.writestr("SHA256SUMS","\n".join(hashes)+"\n")
print("Private project packaged; no VPN configuration included.")
