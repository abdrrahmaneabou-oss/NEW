#!/usr/bin/env python3
"""Repack from original entries, retaining even the oversized asset path."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path
from manifest_fgs import fix_manifest

p=argparse.ArgumentParser()
p.add_argument("original",type=Path)
p.add_argument("rebuilt",type=Path)
p.add_argument("extra_dex",type=Path)
p.add_argument("native",type=Path)
p.add_argument("output",type=Path)
p.add_argument("--report",required=True,type=Path)
p.add_argument("--private-package",action="store_true")
a=p.parse_args()
changed=[]; unchanged=[]
with zipfile.ZipFile(a.original) as original, zipfile.ZipFile(a.rebuilt) as rebuilt, zipfile.ZipFile(a.output,"w") as target:
    for info in original.infolist():
        if info.filename.upper().startswith("META-INF/") and info.filename.upper().endswith((".RSA",".DSA",".EC",".SF","MANIFEST.MF")):
            continue
        payload=original.read(info)
        if info.filename in ("classes.dex","classes2.dex"):
            replacement=rebuilt.read(info.filename)
            changed.append({"file":info.filename,"original_sha256":hashlib.sha256(payload).hexdigest(),"new_sha256":hashlib.sha256(replacement).hexdigest()})
            payload=replacement
        elif info.filename=="AndroidManifest.xml" and a.private_package:
            replacements=[("com.fox.onev8","com.fox.awg12"),
                          ("com.ponie.dayov12.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSIONfnspjs", "com.ponie.dayaw12.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSIONfnspjs"),
                          ("FOX ONE","FOX AWG")]
            old=payload
            # All replacements have identical UTF-8/UTF-16 lengths: pool offsets
            # and Android binary XML structure remain intact.
            for before,after in replacements:
                assert len(before)==len(after)
                for encoding in ("utf-8","utf-16le"):
                    payload=payload.replace(before.encode(encoding),after.encode(encoding))
            payload=fix_manifest(payload)
            assert payload!=old
            changed.append({"file":info.filename,"original_sha256":hashlib.sha256(old).hexdigest(),"new_sha256":hashlib.sha256(payload).hexdigest()})
        else:
            unchanged.append(info.filename)
        target.writestr(info,payload)
    target.write(a.extra_dex,"classes3.dex",compress_type=zipfile.ZIP_DEFLATED)
    target.write(a.native,"lib/arm64-v8a/libfox-awg.so",compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(a.original) as original, zipfile.ZipFile(a.output) as target:
    assert all(original.read(name)==target.read(name) for name in unchanged)
    assert target.testzip() is None
a.report.write_text(json.dumps({"changed":changed,"original_entries_retained_exactly":len(unchanged),"new_entries":["classes3.dex","lib/arm64-v8a/libfox-awg.so"]},indent=2))
