#!/usr/bin/env python3
"""Post-build semantic audit of final DEX, identity, assets and secret absence."""
import argparse
import base64
import hashlib
import json
import zipfile
from pathlib import Path
from loguru import logger
logger.remove()
from androguard.core.axml import AXMLPrinter
from androguard.core.dex import DEX

p=argparse.ArgumentParser()
p.add_argument("original",type=Path)
p.add_argument("final",type=Path)
p.add_argument("--config",type=Path,required=True)
p.add_argument("--report",type=Path,required=True)
a=p.parse_args()

def methods(z):
    result={}
    for name in z.namelist():
        if name.startswith("classes") and name.endswith(".dex"):
            dex=DEX(z.read(name))
            for c in dex.get_classes():
                for m in c.get_methods():
                    code=m.get_code()
                    if code:
                        result[(c.get_name(),m.get_name(),m.get_descriptor())]=[(i.get_name(),i.get_output()) for i in code.get_bc().get_instructions()]
    return result

with zipfile.ZipFile(a.original) as original,zipfile.ZipFile(a.final) as final:
    root=AXMLPrinter(final.read("AndroidManifest.xml")).get_xml_obj()
    ns="{http://schemas.android.com/apk/res/android}"
    assert root.get("package")=="com.fox.awg12"
    assert root.find("application").get(ns+"label")=="FOX AWG"
    assert sum(s.get(ns+"permission")=="android.permission.BIND_VPN_SERVICE" for s in root.findall("application/service"))==1
    for s in root.findall("application/service"):
        assert s.get(ns+"foregroundServiceType")=="0x40000000"
        assert s.find("property").get(ns+"name")=="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
    assert any(s.get(ns+"name")=="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" for s in root.findall("uses-permission"))
    before,after=methods(original),methods(final)
    critical=[]
    for key,value in before.items():
        cl,name,descriptor=key
        if cl=="Lcom/ponie/dayov12/MyVpnService;" and name in (
            "handleIPv4Packet","shouldFreezeDropPacket","shouldGhostDropPacket","_flushFreezeBuffer",
            "_doTele","_startTeleInfinity","_startJitterInfinity","handleTcpProtocol","mkPkt","writeTunSafe"):
            assert value==after[key],name
            critical.append(name+descriptor)
        if cl in ("Lcom/ponie/dayov12/MyVpnService$RecvRunnable;","Lcom/ponie/dayov12/MyVpnService$3;","Lcom/ponie/dayov12/MyVpnService$4;"):
            assert value==after[key],cl+name
            critical.append(cl+name+descriptor)
    assert len(critical)>=12
    login=after[("Lcom/ponie/dayov12/LoginActivity;","onCreate","(Landroid/os/Bundle;)V")]
    assert not any("verify" in operand or "attemptLogin" in operand or "setContentView" in operand for _,operand in login)
    assert any("MainActivity" in operand for _,operand in login)
    assert any("FoxTransport;->run" in operand for _,operand in after[("Lcom/ponie/dayov12/MyVpnService;","run","()V")])
    original_assets=[n for n in original.namelist() if n.startswith("assets/")]
    assert all(original.read(n)==final.read(n) for n in original_assets)
    secrets=[]
    for line in a.config.read_text().splitlines():
        if "=" not in line:continue
        k,v=line.split("=",1)
        if k.strip() in ("PrivateKey","PresharedKey","HeaderProtectionKey"):
            v=v.strip(); raw=base64.b64decode(v)
            secrets.extend((v.encode(),raw,raw.hex().encode()))
    for name in final.namelist():
        data=final.read(name)
        assert not any(s in data for s in secrets),"Secret embedded in "+name
    report={"package":"com.fox.awg12","label":"FOX AWG","vpn_service_count":1,
            "critical_method_semantic_matches":critical,"original_assets_preserved":len(original_assets),
            "private_keys_not_embedded":True,"sha256":hashlib.sha256(a.final.read_bytes()).hexdigest(),
            "device_tested":False,"real_server_handshake_tested":False}
    a.report.write_text(json.dumps(report,indent=2))
    print("PASS: final DEX semantic audit, one VPN service, private identity, original assets, no embedded secrets.")
