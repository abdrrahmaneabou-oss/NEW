"""Minimal binary-XML editor for FGS metadata; keeps original resource IDs."""
import struct

U32=lambda b,o: struct.unpack_from("<I",b,o)[0]
U16=lambda b,o: struct.unpack_from("<H",b,o)[0]
NONE=0xffffffff

def chunks(data):
    pos=8
    while pos<len(data):
        size=U32(data,pos+4)
        if size<8 or pos+size>len(data):raise ValueError("Invalid XML chunk")
        yield data[pos:pos+size]
        pos+=size
    assert pos==len(data)

def length8(b,p):
    n=b[p]; p+=1
    if n&128: n=((n&127)<<8)|b[p]; p+=1
    return n,p

def length16(b,p):
    n=U16(b,p);p+=2
    if n&0x8000:n=((n&0x7fff)<<16)|U16(b,p);p+=2
    return n,p

def enc8(n):return bytes([n]) if n<128 else bytes([128|(n>>8),n&255])
def enc16(n):return struct.pack("<H",n) if n<0x8000 else struct.pack("<HH",0x8000|(n>>16),n&65535)

def pool_strings(chunk):
    header=U16(chunk,2);count=U32(chunk,8);styles=U32(chunk,12);flags=U32(chunk,16);start=U32(chunk,20)
    assert header==28 and styles==0
    result=[]
    for i in range(count):
        p=start+U32(chunk,28+4*i)
        if flags&0x100:
            _,p=length8(chunk,p);n,p=length8(chunk,p);result.append(chunk[p:p+n].decode("utf-8"))
        else:
            n,p=length16(chunk,p);result.append(chunk[p:p+2*n].decode("utf-16le"))
    return result,flags

def make_pool(strings,flags):
    offsets=[];payload=bytearray()
    for s in strings:
        offsets.append(len(payload));units=len(s.encode("utf-16le"))//2
        if flags&0x100:
            encoded=s.encode("utf-8");payload+=enc8(units)+enc8(len(encoded))+encoded+b"\0"
        else:payload+=enc16(units)+s.encode("utf-16le")+b"\0\0"
    payload+=b"\0"*((-len(payload))%4)
    start=28+4*len(strings);size=start+len(payload)
    return struct.pack("<HHIIIIII",1,28,size,len(strings),0,flags&~1,start,0)+struct.pack("<"+"I"*len(offsets),*offsets)+payload

def attributes(chunk,strings):
    if U16(chunk,0)!=0x0102:return []
    pos=16+U16(chunk,24);count=U16(chunk,28);size=U16(chunk,26)
    result=[]
    for i in range(count):
        p=pos+i*size;name=strings[U32(chunk,p+4)];raw=U32(chunk,p+8);kind=chunk[p+15];value=U32(chunk,p+16)
        result.append((name,p,strings[raw] if raw!=NONE else strings[value] if kind==3 else value))
    return result

def element(tag,attrs,line=1):
    payload=struct.pack("<IIHHHHHH",NONE,tag,20,20,len(attrs),0,0,0)
    for namespace,name,value in attrs:
        payload+=struct.pack("<IIIHBBI",namespace,name,value,8,0,3,value)
    return struct.pack("<HHIII",0x0102,16,16+len(payload),line,NONE)+payload

def end_element(tag,line=1):return struct.pack("<HHIIIII",0x0103,16,24,line,NONE,NONE,tag)

def fix_manifest(data):
    parts=list(chunks(data));pool=next(p for p in parts if U16(p,0)==1);strings,flags=pool_strings(pool)
    def index(s):
        if s not in strings:strings.append(s)
        return strings.index(s)
    ns=index("http://schemas.android.com/apk/res/android");name=index("name");value=index("value")
    permission=index("android.permission.FOREGROUND_SERVICE_SPECIAL_USE")
    subtype=index("android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE");prop=index("property")
    explanations={
        "com.ponie.dayov12.MyVpnService":index("User-controlled AmneziaWG VPN tunnel"),
        "com.ponie.dayov12.FloatingService":index("User-controlled floating packet controls")
    }
    permission_tag=index("uses-permission")
    result=[];current=None;changed=0;added_permission=False
    for chunk in parts:
        kind=U16(chunk,0)
        if kind==1:
            result.append(make_pool(strings,flags));continue
        if kind==0x0102:
            tag=strings[U32(chunk,20)];attrs=attributes(chunk,strings)
            if tag=="application" and not added_permission:
                result.extend((element(permission_tag,[(ns,name,permission)]),end_element(permission_tag)))
                added_permission=True
            if tag=="service":
                current=next((v for k,p,v in attrs if k=="name"),None)
                if current in explanations:
                    updated=bytearray(chunk)
                    for k,p,v in attrs:
                        if k=="foregroundServiceType":
                            struct.pack_into("<I",updated,p+8,NONE)
                            updated[p+15]=0x11
                            struct.pack_into("<I",updated,p+16,0x40000000)
                            changed+=1
                    chunk=bytes(updated)
        elif kind==0x0103 and strings[U32(chunk,20)]=="service":
            if current in explanations:
                result.extend((element(prop,[(ns,name,subtype),(ns,value,explanations[current])]),end_element(prop)))
            current=None
        result.append(chunk)
    assert changed==2 and added_permission
    output=b"".join(result)
    return struct.pack("<HHI",3,8,len(output)+8)+output
