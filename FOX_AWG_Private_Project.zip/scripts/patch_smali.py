#!/usr/bin/env python3
"""Mechanical, audited APK patch. Never uses decompiled Java as app source."""
import argparse
import hashlib
import json
import re
import shutil
from pathlib import Path


def method(text, signature, transform):
    pattern = re.compile(r"(?m)^\.method " + re.escape(signature) + r"\n.*?^\.end method", re.S | re.M)
    matches = list(pattern.finditer(text))
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one method: {signature}; found {len(matches)}")
    return pattern.sub(lambda m: transform(m.group(0)), text, count=1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("original", type=Path)
    p.add_argument("destination", type=Path)
    p.add_argument("--report", type=Path, required=True)
    args = p.parse_args()
    if args.destination.exists():
        raise SystemExit("Destination already exists; preserve prior work")
    shutil.copytree(args.original, args.destination)
    changed = []

    def update(relative, edit):
        path = args.destination / relative
        original = path.read_text()
        revised = edit(original)
        if original == revised:
            raise ValueError("No change: " + relative)
        path.write_text(revised)
        changed.append({"file": relative, "before": hashlib.sha256(original.encode()).hexdigest(),
                        "after": hashlib.sha256(revised.encode()).hexdigest()})

    login_create = """.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    const-wide/16 v0, 0x2
    sput-wide v0, Lcom/ponie/dayov12/LoginActivity;->key:J
    new-instance v0, Landroid/content/Intent;
    const-class v1, Lcom/ponie/dayov12/MainActivity;
    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    return-void
.end method"""

    def edit_login(text):
        text = method(text, "protected onCreate(Landroid/os/Bundle;)V", lambda _: login_create)
        # Keep nonzero compatibility marker for the original overlay checks.
        return method(text, "static constructor <clinit>()V", lambda m: re.sub(
            r"\.locals (\d+)", lambda n: ".locals "+str(max(2,int(n.group(1)))), m, count=1).replace(
            "    return-void", "    const-wide/16 v0, 0x2\n    sput-wide v0, Lcom/ponie/dayov12/LoginActivity;->key:J\n    return-void"))
    update("smali_classes2/com/ponie/dayov12/LoginActivity.smali", edit_login)

    def edit_main(text):
        text = method(text, "public onCreate(Landroid/os/Bundle;)V", lambda m: m.replace("public onCreate(", "public foxOriginalOnCreate(", 1))
        text = method(text, "protected onActivityResult(IILandroid/content/Intent;)V", lambda m: m.replace("protected onActivityResult(", "protected foxOriginalActivityResult(", 1))
        return text + """
.method public onCreate(Landroid/os/Bundle;)V
    .locals 0
    invoke-virtual {p0, p1}, Lcom/ponie/dayov12/MainActivity;->foxOriginalOnCreate(Landroid/os/Bundle;)V
    invoke-static {p0}, Lcom/ponie/dayov12/FoxAwgUi;->attach(Landroid/app/Activity;)V
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 1
    invoke-static {p0, p1, p2, p3}, Lcom/ponie/dayov12/FoxAwgUi;->result(Landroid/app/Activity;IILandroid/content/Intent;)Z
    move-result v0
    if-nez v0, :fox_result_done
    invoke-virtual {p0, p1, p2, p3}, Lcom/ponie/dayov12/MainActivity;->foxOriginalActivityResult(IILandroid/content/Intent;)V
    :fox_result_done
    return-void
.end method
"""
    update("smali_classes2/com/ponie/dayov12/MainActivity.smali", edit_main)

    def reroute_protection(text):
        # Three existing inner forwarding sockets must enter the system TUN.
        return re.sub(r"invoke-virtual (\{[^\n]+\}), Lcom/ponie/dayov12/MyVpnService;->protect\((Ljava/net/(?:DatagramSocket|Socket);)\)Z",
                      r"invoke-static \1, Lcom/ponie/dayov12/FoxTransport;->protectInner(Lcom/ponie/dayov12/MyVpnService;\2)Z", text)

    def edit_service(text):
        text = reroute_protection(text)
        text = method(text,"public onStartCommand(Landroid/content/Intent;II)I",lambda m:m.replace("public onStartCommand(","public foxOriginalStartCommand(",1))
        text = method(text, "public run()V", lambda _: """.method public run()V
    .locals 0
    invoke-static {p0}, Lcom/ponie/dayov12/FoxTransport;->run(Lcom/ponie/dayov12/MyVpnService;)V
    return-void
.end method""")
        text=method(text, "doStop()V", lambda m: re.sub(r"(\.locals \d+)",
            r"\1\n\n    invoke-static {p0}, Lcom/ponie/dayov12/FoxTransport;->stop(Lcom/ponie/dayov12/MyVpnService;)V", m, count=1))
        return text+"""
.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1
    invoke-static {p0, p1}, Lcom/ponie/dayov12/FoxTransport;->command(Lcom/ponie/dayov12/MyVpnService;Landroid/content/Intent;)Landroid/content/Intent;
    move-result-object p1
    invoke-virtual {p0, p1, p2, p3}, Lcom/ponie/dayov12/MyVpnService;->foxOriginalStartCommand(Landroid/content/Intent;II)I
    move-result v0
    return v0
.end method
"""
    update("smali/com/ponie/dayov12/MyVpnService.smali", edit_service)
    for name in ("MyVpnService$1", "MyVpnService$5"):
        update("smali/com/ponie/dayov12/" + name + ".smali", reroute_protection)

    # Prove the critical packet processing and replay bodies have not changed.
    service = "smali/com/ponie/dayov12/MyVpnService.smali"
    before = (args.original/service).read_text()
    after = (args.destination/service).read_text()
    unchanged = []
    for signature in (
        "handleIPv4Packet([BILjava/nio/channels/FileChannel;)V",
        "shouldFreezeDropPacket(I)Z", "shouldGhostDropPacket(I)Z",
        "_flushFreezeBuffer()V", "_doTele(IZ)V", "_startTeleInfinity(Z)V",
        "_startJitterInfinity()V", "handleTcpProtocol([BILjava/nio/channels/FileChannel;)V",
        "writeTunSafe(Ljava/nio/channels/FileChannel;[B)V"
    ):
        pattern = re.compile(r"(?m)^\.method " + re.escape(signature) + r"\n.*?^\.end method", re.S | re.M)
        a, b = pattern.findall(before), pattern.findall(after)
        assert len(a) == len(b) == 1 and a == b, signature
        unchanged.append(signature)
    for relative in ("smali/com/ponie/dayov12/MyVpnService$RecvRunnable.smali",
                     "smali/com/ponie/dayov12/MyVpnService$3.smali",
                     "smali/com/ponie/dayov12/MyVpnService$4.smali"):
        assert (args.original/relative).read_bytes() == (args.destination/relative).read_bytes()
        unchanged.append(relative)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps({"changed": changed, "unchanged_verified": unchanged}, indent=2))


if __name__ == "__main__":
    main()
