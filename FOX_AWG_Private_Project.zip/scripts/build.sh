#!/usr/bin/env bash
set -euo pipefail
FOX_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FOX_BUILD="$(mktemp -d "$FOX_ROOT/build-XXXXXX")"
FOX_APKTOOL="${FOX_APKTOOL:-$FOX_ROOT/tools/apktool.jar}"
FOX_ECJ="${FOX_ECJ:-$FOX_ROOT/tools/ecj.jar}"
FOX_ANDROID_JAR="${FOX_ANDROID_JAR:-$FOX_ROOT/tools/sdk-platform/android-35/android.jar}"
FOX_BUILD_TOOLS="${FOX_BUILD_TOOLS:-$FOX_ROOT/tools/sdk-build/android-15}"
FOX_GO="${FOX_GO:-$FOX_ROOT/tools/go/bin/go}"
FOX_CC="${FOX_CC:-$FOX_ROOT/tools/android-ndk-r27d/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android29-clang}"
FOX_GO_ROOT="$($FOX_GO env GOROOT)"
if ! rg --quiet 'CLOCK_BOOTTIME' "$FOX_GO_ROOT/src/runtime/sys_linux_arm64.s"; then
    echo 'Use a private Go 1.25.0 distribution with src/native/clock-arm64.patch applied.' >&2
    exit 1
fi
mkdir -p "$FOX_BUILD/classes" "$FOX_BUILD/dex" "$FOX_ROOT/output"
java -jar "$FOX_APKTOOL" d -r "$FOX_ROOT/input/FOX_ORIGINAL.apk" -o "$FOX_BUILD/original"
python3 "$FOX_ROOT/scripts/patch_smali.py" "$FOX_BUILD/original" "$FOX_BUILD/patched" --report "$FOX_BUILD/patch-audit.json"
java -jar "$FOX_APKTOOL" b "$FOX_BUILD/patched" -o "$FOX_BUILD/rebuilt.apk"
java -jar "$FOX_ECJ" -source 1.8 -target 1.8 -cp "$FOX_ANDROID_JAR" -d "$FOX_BUILD/classes" \
    "$FOX_ROOT"/src/java/com/ponie/dayov12/*.java "$FOX_ROOT/src/stubs/com/ponie/dayov12/MyVpnService.java"
(cd "$FOX_BUILD/classes" && zip -q -r "$FOX_BUILD/added.jar" com/ponie/dayov12 -i '*Fox*')
java -cp "$FOX_BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 29 --lib "$FOX_ANDROID_JAR" --output "$FOX_BUILD/dex" "$FOX_BUILD/added.jar"
(cd "$FOX_ROOT/src/native" && GOOS=android GOARCH=arm64 CGO_ENABLED=1 CC="$FOX_CC" \
    CGO_LDFLAGS='-Wl,-z,max-page-size=16384 -Wl,-soname,libfox-awg.so' \
    "$FOX_GO" build -trimpath -buildvcs=false -buildmode=c-shared -o "$FOX_BUILD/libfox-awg.so" .)
python3 "$FOX_ROOT/scripts/repack_apk.py" "$FOX_ROOT/input/FOX_ORIGINAL.apk" "$FOX_BUILD/rebuilt.apk" \
    "$FOX_BUILD/dex/classes.dex" "$FOX_BUILD/libfox-awg.so" "$FOX_BUILD/unsigned.apk" --private-package --report "$FOX_BUILD/repack-audit.json"
"$FOX_BUILD_TOOLS/zipalign" -P 16 -f 4 "$FOX_BUILD/unsigned.apk" "$FOX_BUILD/aligned.apk"
java -jar "$FOX_BUILD_TOOLS/lib/apksigner.jar" sign --ks "$FOX_ROOT/signing/private-build-signing.p12" \
    --ks-pass pass:fox-private-build --out "$FOX_ROOT/output/FOX_AWG_Experimental.apk" "$FOX_BUILD/aligned.apk"
java -jar "$FOX_BUILD_TOOLS/lib/apksigner.jar" verify --verbose "$FOX_ROOT/output/FOX_AWG_Experimental.apk"
echo 'Built experimental private APK; device testing is still required.'
